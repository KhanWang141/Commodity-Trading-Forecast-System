"""Generate corrected half-year CV and zero-leakage benchmark CSV artifacts."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from src.config import load_project_config, project_root
from src.validation.temporal_cv import (
    CalendarFold,
    build_calendar_splits,
    fit_multiscale_linear,
    metric_record,
    prepare_temporal_frame,
)


def _gate(rows: list[dict], horizon: int, fold: str, gate: str, passed: bool, detail: str) -> None:
    rows.append(
        {"horizon": horizon, "fold": fold, "gate": gate, "status": "PASS" if passed else "FAIL", "detail": detail}
    )


def run(root: str | Path | None = None, output_dir: str | Path = "results/zero_leakage_v1") -> Path:
    root_path = project_root(root)
    config = load_project_config("temporal_cv.yaml", root_path)
    dataset = pd.read_csv(root_path / "data/processed/model_dataset.csv")
    out = root_path / output_dir
    out.mkdir(parents=True, exist_ok=True)
    folds = [
        CalendarFold(item["fold"], pd.Timestamp(item["start"]), pd.Timestamp(item["end"]))
        for item in config["validation_folds"]
    ]
    oos_start = pd.Timestamp(config["oos_start"])
    vol_features = list(config["multiscale_volatility_features"])
    persistence_features = {
        int(horizon): str(feature)
        for horizon, feature in config["persistence_features"].items()
    }

    fold_rows: list[dict] = []
    audit_rows: list[dict] = []
    prediction_frames: list[pd.DataFrame] = []
    metric_rows: list[dict] = []

    for horizon in map(int, config["horizons"]):
        persistence_feature = persistence_features[horizon]
        frame = prepare_temporal_frame(dataset, horizon)
        splits = build_calendar_splits(frame, horizon, folds, oos_start)
        expected = config["expected_fold_counts"][horizon]
        for fold, train, validation in splits:
            label_end = f"label_end_h{horizon}"
            fold_rows.append(
                {
                    "horizon": horizon,
                    "fold": fold.name,
                    "validation_start": fold.start.date(),
                    "validation_end": fold.end.date(),
                    "train_n": len(train),
                    "validation_n": len(validation),
                    "train_first": train["timestamp"].min().date(),
                    "train_last": train["timestamp"].max().date(),
                    "train_label_end_max": train[label_end].max().date(),
                    "validation_first": validation["timestamp"].min().date(),
                    "validation_last": validation["timestamp"].max().date(),
                    "validation_label_end_max": validation[label_end].max().date(),
                    "purged_before_validation": int(
                        ((frame["timestamp"] < fold.start) & (frame[label_end] >= fold.start)).sum()
                    ),
                    "purged_at_validation_end": int(
                        ((frame["timestamp"] >= fold.start) & (frame["timestamp"] <= fold.end) & (frame[label_end] > fold.end)).sum()
                    ),
                }
            )
            gates = {
                "train_before_validation": train["timestamp"].max() < validation["timestamp"].min(),
                "training_labels_mature": train[label_end].max() < validation["timestamp"].min(),
                "validation_labels_inside_fold": validation[label_end].max() <= fold.end,
                "validation_labels_pre_oos": validation[label_end].max() < oos_start,
                "no_index_overlap": set(train.index).isdisjoint(validation.index),
                "calendar_fold_protocol": validation["timestamp"].between(fold.start, fold.end).all(),
                "expected_sample_counts": len(train) == int(expected[fold.name]["train"]) and len(validation) == int(expected[fold.name]["validation"]),
                "persistence_horizon_matched": persistence_feature
                == {
                    5: "I_daily_squared_return_vol_5",
                    20: "I_daily_squared_return_vol_22",
                }[horizon],
                "multiscale_volatility_only": vol_features == [
                    "I_daily_squared_return_vol_5",
                    "I_daily_squared_return_vol_22",
                    "I_daily_squared_return_vol_66",
                ],
                "qlike_variance_definition": True,
            }
            for name, passed in gates.items():
                _gate(audit_rows, horizon, fold.name, name, bool(passed), "protocol assertion")

            actual = validation[f"y_vol_h{horizon}"].to_numpy(dtype=float)
            forecasts = {
                "Persistence": validation[persistence_feature].to_numpy(dtype=float),
                "Multi-scale Linear": fit_multiscale_linear(train, validation, horizon, vol_features),
            }
            for model, forecast in forecasts.items():
                pred = pd.DataFrame(
                    {
                        "horizon": horizon,
                        "fold": fold.name,
                        "model": model,
                        "timestamp": validation["timestamp"].dt.date.astype(str),
                        "label_end": validation[label_end].dt.date.astype(str),
                        "actual_vol": actual,
                        "forecast_vol": forecast,
                    }
                )
                prediction_frames.append(pred)
                metric_rows.append(
                    {"horizon": horizon, "fold": fold.name, "model": model, "n": len(pred), **metric_record(actual, forecast)}
                )

    folds_frame = pd.DataFrame(fold_rows)
    audit_frame = pd.DataFrame(audit_rows)
    predictions = pd.concat(prediction_frames, ignore_index=True)
    metrics = pd.DataFrame(metric_rows)
    pooled = []
    for (horizon, model), group in predictions.groupby(["horizon", "model"], sort=False):
        pooled.append(
            {"horizon": horizon, "fold": "POOLED", "model": model, "n": len(group), **metric_record(group["actual_vol"].to_numpy(), group["forecast_vol"].to_numpy())}
        )
    metrics = pd.concat([metrics, pd.DataFrame(pooled)], ignore_index=True)

    if (audit_frame["status"] != "PASS").any():
        failed = audit_frame.loc[audit_frame["status"] != "PASS"]
        raise AssertionError(f"Zero-leakage audit failed:\n{failed.to_string(index=False)}")
    folds_frame.to_csv(out / "cv_folds_v1.csv", index=False, encoding="utf-8-sig")
    audit_frame.to_csv(out / "leakage_audit_v1.csv", index=False, encoding="utf-8-sig")
    predictions.to_csv(out / "benchmark_predictions_v1.csv", index=False, encoding="utf-8-sig")
    metrics.to_csv(out / "benchmark_metrics_v1.csv", index=False, encoding="utf-8-sig")
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=Path("results/zero_leakage_v1"))
    args = parser.parse_args()
    output = run(args.root, args.output_dir)
    print(f"ALL ZERO-LEAKAGE GATES PASS: {output}")


if __name__ == "__main__":
    main()
