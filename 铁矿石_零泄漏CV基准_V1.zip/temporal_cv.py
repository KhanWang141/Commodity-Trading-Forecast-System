"""Calendar CV, label maturity, benchmarks, and leakage audit utilities."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class CalendarFold:
    """One pre-registered calendar validation interval."""

    name: str
    start: pd.Timestamp
    end: pd.Timestamp


def _as_local_date(values: pd.Series) -> pd.Series:
    """Preserve the recorded Shanghai calendar date while removing time-zone syntax."""
    return pd.to_datetime(values.astype(str).str.slice(0, 10), errors="raise")


def prepare_temporal_frame(frame: pd.DataFrame, horizon: int) -> pd.DataFrame:
    """Return the common eligible sample with normalized timestamp columns."""
    required = {
        "timestamp",
        f"label_end_h{horizon}",
        f"eligible_continuous_{horizon}",
        f"y_vol_h{horizon}",
        f"logV_h{horizon}",
    }
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    result = frame.loc[frame[f"eligible_continuous_{horizon}"].astype(bool)].copy()
    result["timestamp"] = _as_local_date(result["timestamp"])
    result[f"label_end_h{horizon}"] = _as_local_date(result[f"label_end_h{horizon}"])
    result = result.sort_values("timestamp").reset_index(drop=True)
    if result["timestamp"].duplicated().any():
        raise AssertionError("Eligible sample contains duplicate timestamps")
    return result


def build_calendar_splits(
    frame: pd.DataFrame,
    horizon: int,
    folds: Iterable[CalendarFold],
    oos_start: pd.Timestamp,
) -> list[tuple[CalendarFold, pd.DataFrame, pd.DataFrame]]:
    """Build expanding folds with mature train and within-fold mature validation labels."""
    label_end = f"label_end_h{horizon}"
    oos_start = pd.Timestamp(oos_start)
    splits = []
    for fold in folds:
        # Strict maturity prevents a training label from using validation prices.
        train = frame.loc[
            (frame["timestamp"] < fold.start) & (frame[label_end] < fold.start)
        ].copy()
        # Validation labels must finish inside their registered half-year and pre-OOS.
        validation = frame.loc[
            (frame["timestamp"] >= fold.start)
            & (frame["timestamp"] <= fold.end)
            & (frame[label_end] <= fold.end)
            & (frame[label_end] < oos_start)
        ].copy()
        if train.empty or validation.empty:
            raise AssertionError(f"Empty train/validation sample in {fold.name}, h={horizon}")
        splits.append((fold, train, validation))
    return splits


def fit_multiscale_linear(
    train: pd.DataFrame,
    validation: pd.DataFrame,
    horizon: int,
    volatility_features: list[str],
) -> np.ndarray:
    """Fit fold-local OLS on log volatility scales only and return level forecasts."""
    if any("cumret" in name.lower() or not name.lower().endswith("_vol_5")
           and not name.lower().endswith("_vol_22")
           and not name.lower().endswith("_vol_66") for name in volatility_features):
        raise AssertionError("Multi-scale Linear must not contain return features")
    x_train = np.log(train[volatility_features].to_numpy(dtype=float))
    x_valid = np.log(validation[volatility_features].to_numpy(dtype=float))
    if not np.isfinite(x_train).all() or not np.isfinite(x_valid).all():
        raise AssertionError("Multi-scale log-volatility inputs must be positive and finite")
    design_train = np.column_stack([np.ones(len(train)), x_train])
    design_valid = np.column_stack([np.ones(len(validation)), x_valid])
    coefficients, *_ = np.linalg.lstsq(
        design_train,
        train[f"logV_h{horizon}"].to_numpy(dtype=float),
        rcond=None,
    )
    return np.exp(design_valid @ coefficients)


def qlike_variance(actual_vol: np.ndarray, forecast_vol: np.ndarray) -> float:
    """Standard variance QLIKE using V^2 / Vhat^2."""
    actual = np.asarray(actual_vol, dtype=float)
    forecast = np.asarray(forecast_vol, dtype=float)
    if np.any(actual <= 0) or np.any(forecast <= 0):
        raise ValueError("QLIKE requires strictly positive volatilities")
    ratio = np.square(actual) / np.square(forecast)
    return float(np.mean(ratio - np.log(ratio) - 1.0))


def metric_record(actual: np.ndarray, forecast: np.ndarray) -> dict[str, float]:
    """Compute level RMSE/MAE and variance QLIKE."""
    errors = np.asarray(forecast) - np.asarray(actual)
    return {
        "rmse": float(np.sqrt(np.mean(np.square(errors)))),
        "mae": float(np.mean(np.abs(errors))),
        "qlike": qlike_variance(actual, forecast),
    }
