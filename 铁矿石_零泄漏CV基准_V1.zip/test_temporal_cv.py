from __future__ import annotations

import numpy as np
import pandas as pd

from src.config import load_project_config
from src.validation.temporal_cv import qlike_variance


def test_qlike_uses_variance_ratio():
    actual = np.array([2.0])
    forecast = np.array([1.0])
    assert np.isclose(qlike_variance(actual, forecast), 4.0 - np.log(4.0) - 1.0)


def test_qlike_is_zero_for_perfect_forecast():
    values = np.array([0.1, 0.2, 0.3])
    assert np.isclose(qlike_variance(values, values), 0.0)


def test_persistence_is_horizon_matched():
    config = load_project_config("temporal_cv.yaml")
    assert config["persistence_features"] == {
        5: "I_daily_squared_return_vol_5",
        20: "I_daily_squared_return_vol_22",
    }
