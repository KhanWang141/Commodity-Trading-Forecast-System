# 零泄漏基准测试 V1

本目录由项目根目录下的 `run_zero_leakage_benchmarks.py` 生成。

- `cv_folds_v1.csv`：2020H2—2022H2 五个日历半年折；训练标签必须在验证期开始前成熟，验证标签必须在本折结束前成熟。
- `leakage_audit_v1.csv`：每个期限、每一折的协议门禁结果。
- `benchmark_predictions_v1.csv`：Persistence 与 Multi-scale Linear 的逐日验证预测。
- `benchmark_metrics_v1.csv`：逐折及合并验证预测后的 RMSE、MAE、方差 QLIKE。

冻结定义：

- Persistence 采用期限匹配定义：h=5 使用铁矿石 5 日历史波动率，h=20 使用 22 日历史波动率。
- Multi-scale Linear 仅使用 `log(Vol5)`、`log(Vol22)`、`log(Vol66)`，不含收益率。
- QLIKE 为 `V^2 / Vhat^2 - log(V^2 / Vhat^2) - 1`。
- 合并行 `POOLED` 是拼接五折预测后一次性计算，不是五个折指标的简单平均。

复现命令：

```powershell
python run_zero_leakage_benchmarks.py
```
