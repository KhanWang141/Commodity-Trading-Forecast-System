Continuous Forecast Dataset V1.0

Main files for modelling:
  processed/model_dataset_h5_v1.parquet (or .csv)
  processed/model_dataset_h20_v1.parquet (or .csv)
  config/feature_groups_v1.json

Do not use old split_5/split_20, risk thresholds, or high-volatility labels for this experiment.
A/AB/ABC comparisons must use the same horizon-specific dataset rows.
Ridge scaling must be fitted inside each training fold/month, never globally here.
Expected h=5 rows: 1716; expected h=20 rows: 1700.
