#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Iron Ore Continuous Volatility Forecasting — Main Experiment Protocol V1.0
==========================================================================

This program implements the frozen main experiment:

    V2 data
    + A / AB / ABC hierarchical information sets
    + Ridge / XGBoost CV tuning
    + Persistence / Multi-scale Linear baselines
    + 2023-01 ... 2026-08 monthly expanding-window pseudo-real-time OOS
    + QLIKE / MAE / RMSE / OOS R^2
    + information-increment tables
    + Diebold-Mariano tests with Newey-West HAC, lag = h - 1

IMPORTANT
---------
1. The program assumes the already-audited V2 files are frozen:
       model_dataset_h5_v2.csv
       model_dataset_h20_v2.csv
       cv_folds_h5_v2.csv
       cv_folds_h20_v2.csv
2. Hyperparameters are selected ONLY from the five pre-2023 calendar CV folds.
3. Ridge and XGBoost fit log_y_vol_h; forecasts are exp-transformed before scoring.
4. CV model selection uses the UNWEIGHTED mean of the five fold-level QLIKE values.
5. During OOS, hyperparameters are frozen. Models are re-fit only once per calendar
   month, using labels fully mature before that month's first OOS prediction date.
6. A natural month uses one fixed fitted model; there is no mid-month re-training.
7. The default XGBoost grid is the full frozen 864-combination grid.

Recommended execution sequence
------------------------------
# 1) Ridge CV (quick)
python run_main_experiment_v1.py --data-dir rebuilt_core_v2 --output-dir main_experiment_v1 --stage ridge-cv

# 2) XGBoost CV (computationally expensive; resume supported)
python run_main_experiment_v1.py --data-dir rebuilt_core_v2 --output-dir main_experiment_v1 --stage xgb-cv --resume

# 3) Final OOS using ALL frozen best hyperparameters
python run_main_experiment_v1.py --data-dir rebuilt_core_v2 --output-dir main_experiment_v1 --stage oos --resume

# Or run everything in one command
python run_main_experiment_v1.py --data-dir rebuilt_core_v2 --output-dir main_experiment_v1 --stage all

For exact reproducibility, keep --xgb-n-jobs 1 (default).
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import platform
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd
import scipy
from scipy.stats import norm
import sklearn
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
import xgboost
from xgboost import XGBRegressor


# -----------------------------------------------------------------------------
# Frozen protocol constants
# -----------------------------------------------------------------------------

PROTOCOL_NAME = "Iron Ore Main Experiment Protocol V1.0"
GLOBAL_SEED = 42
HORIZONS = (5, 20)
OOS_START = pd.Timestamp("2023-01-01")
OOS_END = pd.Timestamp("2026-08-31")
TIE_ATOL = 1e-12

CV_FOLDS = [
    ("2020H2", pd.Timestamp("2020-07-01"), pd.Timestamp("2020-12-31")),
    ("2021H1", pd.Timestamp("2021-01-01"), pd.Timestamp("2021-06-30")),
    ("2021H2", pd.Timestamp("2021-07-01"), pd.Timestamp("2021-12-31")),
    ("2022H1", pd.Timestamp("2022-01-01"), pd.Timestamp("2022-06-30")),
    ("2022H2", pd.Timestamp("2022-07-01"), pd.Timestamp("2022-12-31")),
]

A_FEATURES = [
    "I_cumret_5",
    "I_cumret_22",
    "I_cumret_66",
    "I_daily_squared_return_vol_5",
    "I_daily_squared_return_vol_22",
    "I_daily_squared_return_vol_66",
]

B_ADD_FEATURES = [
    f"{symbol}_{kind}_{window}"
    for symbol in ("RB", "J", "JM")
    for kind in ("cumret", "daily_squared_return_vol")
    for window in (5, 22, 66)
]

C_ADD_FEATURES = [
    "cpi_yoy",
    "ppi_yoy",
    "pmi_manufacturing",
    "industrial_value_added_yoy",
    "industrial_value_added_yoy_joint_jan_feb",
]

FEATURE_SETS: dict[str, list[str]] = {
    "A": A_FEATURES,
    "AB": A_FEATURES + B_ADD_FEATURES,
    "ABC": A_FEATURES + B_ADD_FEATURES + C_ADD_FEATURES,
}

MULTISCALE_VOL_FEATURES = [
    "I_daily_squared_return_vol_5",
    "I_daily_squared_return_vol_22",
    "I_daily_squared_return_vol_66",
]

PERSISTENCE_FEATURE = {
    5: "I_daily_squared_return_vol_5",
    20: "I_daily_squared_return_vol_22",
}

RIDGE_ALPHA_CANDIDATES = [
    1e-5,
    1e-4,
    1e-3,
    1e-2,
    0.1,
    1.0,
    10.0,
    100.0,
    1000.0,
]

XGB_GRID = {
    "max_depth": [2, 3, 4, 5],
    "learning_rate": [0.01, 0.05, 0.1],
    "subsample": [0.7, 0.8, 0.9],
    "colsample_bytree": [0.7, 0.8, 0.9],
    "n_estimators": [100, 200],
    "reg_alpha": [0.0, 0.01],
    "reg_lambda": [1.0, 10.0],
}

EXPECTED_XGB_COMBINATIONS = 864


# -----------------------------------------------------------------------------
# Small utilities
# -----------------------------------------------------------------------------


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def json_dump(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def require_columns(frame: pd.DataFrame, columns: Iterable[str], name: str) -> None:
    missing = [c for c in columns if c not in frame.columns]
    if missing:
        raise KeyError(f"{name} missing required columns: {missing}")


def to_date_series(values: pd.Series) -> pd.Series:
    """Parse either ISO dates or timezone-bearing timestamps and normalize to date-only Timestamp."""
    return pd.to_datetime(values.astype(str).str.slice(0, 10), errors="raise")


def atomic_csv(frame: pd.DataFrame, path: Path) -> None:
    """Write a CSV atomically so an interrupted run does not leave a half-written artifact."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temp, index=False, encoding="utf-8-sig")
    temp.replace(path)


def parameter_key(params: dict[str, Any]) -> str:
    return json.dumps(params, sort_keys=True, separators=(",", ":"))


# -----------------------------------------------------------------------------
# Data loading and protocol checks
# -----------------------------------------------------------------------------


@dataclass(frozen=True)
class FoldSplit:
    name: str
    start: pd.Timestamp
    end: pd.Timestamp
    train: pd.DataFrame
    validation: pd.DataFrame


def load_dataset(data_dir: Path, horizon: int) -> pd.DataFrame:
    path = data_dir / f"model_dataset_h{horizon}_v2.csv"
    if not path.exists():
        raise FileNotFoundError(path)

    frame = pd.read_csv(path)
    target = f"y_vol_{horizon}"
    log_target = f"log_y_vol_{horizon}"
    label_end = f"label_end_{horizon}"
    eligible = f"eligible_continuous_{horizon}"
    oos = f"oos_{horizon}"

    require_columns(
        frame,
        ["date", "forecast_time", target, log_target, label_end, eligible, oos]
        + FEATURE_SETS["ABC"],
        path.name,
    )

    frame["date"] = to_date_series(frame["date"])
    frame[label_end] = to_date_series(frame[label_end])
    frame[eligible] = frame[eligible].astype(bool)
    frame[oos] = frame[oos].astype(bool)
    frame = frame.loc[frame[eligible]].copy()
    frame = frame.sort_values("date").reset_index(drop=True)

    if frame["date"].duplicated().any():
        raise AssertionError(f"h={horizon}: duplicate eligible dates")

    numeric = FEATURE_SETS["ABC"] + [target, log_target]
    if not np.isfinite(frame[numeric].to_numpy(dtype=float)).all():
        raise AssertionError(f"h={horizon}: eligible modelling data contain NaN/Inf")
    if not (frame[target] > 0).all():
        raise AssertionError(f"h={horizon}: target must be strictly positive")
    if not np.allclose(
        frame[log_target].to_numpy(dtype=float),
        np.log(frame[target].to_numpy(dtype=float)),
        rtol=1e-11,
        atol=1e-13,
    ):
        raise AssertionError(f"h={horizon}: log_y_vol_h != log(y_vol_h)")

    return frame


def build_calendar_splits(frame: pd.DataFrame, horizon: int) -> list[FoldSplit]:
    label_end = f"label_end_{horizon}"
    splits: list[FoldSplit] = []

    for name, start, end in CV_FOLDS:
        train = frame.loc[
            (frame["date"] < start) & (frame[label_end] < start)
        ].copy()
        validation = frame.loc[
            (frame["date"] >= start)
            & (frame["date"] <= end)
            & (frame[label_end] <= end)
            & (frame[label_end] < OOS_START)
        ].copy()

        if train.empty or validation.empty:
            raise AssertionError(f"h={horizon}, {name}: empty train or validation")
        if train["date"].max() >= validation["date"].min():
            raise AssertionError(f"h={horizon}, {name}: train/validation date order failure")
        if train[label_end].max() >= start:
            raise AssertionError(f"h={horizon}, {name}: training labels not mature")
        if validation[label_end].max() > end:
            raise AssertionError(f"h={horizon}, {name}: validation label spills beyond fold")
        if validation[label_end].max() >= OOS_START:
            raise AssertionError(f"h={horizon}, {name}: validation enters formal OOS")

        splits.append(FoldSplit(name, start, end, train, validation))

    return splits


def assert_cv_artifact_matches(data_dir: Path, horizon: int, splits: list[FoldSplit]) -> pd.DataFrame:
    path = data_dir / f"cv_folds_h{horizon}_v2.csv"
    if not path.exists():
        raise FileNotFoundError(path)
    artifact = pd.read_csv(path)
    require_columns(artifact, ["date", "fold_id", "role"], path.name)
    artifact["date"] = to_date_series(artifact["date"])

    rows: list[dict[str, Any]] = []
    for split in splits:
        for role, expected in (("train", split.train), ("validation", split.validation)):
            stored_dates = set(
                artifact.loc[
                    artifact["fold_id"].eq(split.name) & artifact["role"].eq(role),
                    "date",
                ]
            )
            expected_dates = set(expected["date"])
            passed = stored_dates == expected_dates
            rows.append(
                {
                    "horizon": horizon,
                    "fold": split.name,
                    "role": role,
                    "stored_n": len(stored_dates),
                    "expected_n": len(expected_dates),
                    "only_in_cv_artifact": len(stored_dates - expected_dates),
                    "only_in_internal_split": len(expected_dates - stored_dates),
                    "status": "PASS" if passed else "FAIL",
                }
            )
            if not passed:
                raise AssertionError(
                    f"CV artifact mismatch: h={horizon}, {split.name}, {role}; "
                    f"only_in_artifact={len(stored_dates - expected_dates)}, "
                    f"only_in_internal={len(expected_dates - stored_dates)}"
                )
    return pd.DataFrame(rows)


# -----------------------------------------------------------------------------
# Metrics and model helpers
# -----------------------------------------------------------------------------


def qlike_losses(actual_vol: np.ndarray, forecast_vol: np.ndarray) -> np.ndarray:
    actual = np.asarray(actual_vol, dtype=float)
    forecast = np.asarray(forecast_vol, dtype=float)
    if actual.shape != forecast.shape:
        raise ValueError("QLIKE: actual and forecast shapes differ")
    if not np.isfinite(actual).all() or not np.isfinite(forecast).all():
        raise ValueError("QLIKE: non-finite actual or forecast")
    if np.any(actual <= 0) or np.any(forecast <= 0):
        raise ValueError("QLIKE requires strictly positive volatilities")
    ratio = np.square(actual) / np.square(forecast)
    return ratio - np.log(ratio) - 1.0


def metric_record(actual: np.ndarray, forecast: np.ndarray) -> dict[str, float]:
    actual = np.asarray(actual, dtype=float)
    forecast = np.asarray(forecast, dtype=float)
    error = forecast - actual
    return {
        "qlike": float(np.mean(qlike_losses(actual, forecast))),
        "mae": float(np.mean(np.abs(error))),
        "rmse": float(np.sqrt(np.mean(np.square(error)))),
    }


def fit_predict_multiscale_linear(
    train: pd.DataFrame,
    predict: pd.DataFrame,
    horizon: int,
) -> np.ndarray:
    x_train_raw = train[MULTISCALE_VOL_FEATURES].to_numpy(dtype=float)
    x_pred_raw = predict[MULTISCALE_VOL_FEATURES].to_numpy(dtype=float)
    if np.any(x_train_raw <= 0) or np.any(x_pred_raw <= 0):
        raise AssertionError("Multi-scale Linear requires positive volatility inputs")
    x_train = np.log(x_train_raw)
    x_pred = np.log(x_pred_raw)
    design_train = np.column_stack([np.ones(len(train)), x_train])
    design_pred = np.column_stack([np.ones(len(predict)), x_pred])
    beta, *_ = np.linalg.lstsq(
        design_train,
        train[f"log_y_vol_{horizon}"].to_numpy(dtype=float),
        rcond=None,
    )
    forecast = np.exp(design_pred @ beta)
    if not np.isfinite(forecast).all() or np.any(forecast <= 0):
        raise AssertionError("Invalid Multi-scale Linear forecast")
    return forecast


def fit_predict_ridge(
    train: pd.DataFrame,
    predict: pd.DataFrame,
    horizon: int,
    features: list[str],
    alpha: float,
) -> np.ndarray:
    scaler = StandardScaler(with_mean=True, with_std=True)
    x_train = scaler.fit_transform(train[features].to_numpy(dtype=float))
    x_pred = scaler.transform(predict[features].to_numpy(dtype=float))
    y_train = train[f"log_y_vol_{horizon}"].to_numpy(dtype=float)
    model = Ridge(alpha=float(alpha), fit_intercept=True)
    model.fit(x_train, y_train)
    forecast = np.exp(model.predict(x_pred))
    if not np.isfinite(forecast).all() or np.any(forecast <= 0):
        raise AssertionError("Invalid Ridge forecast")
    return forecast


def make_xgb(params: dict[str, Any], n_jobs: int) -> XGBRegressor:
    return XGBRegressor(
        objective="reg:squarederror",
        random_state=GLOBAL_SEED,
        n_jobs=n_jobs,
        verbosity=0,
        **params,
    )


def fit_predict_xgb(
    train: pd.DataFrame,
    predict: pd.DataFrame,
    horizon: int,
    features: list[str],
    params: dict[str, Any],
    n_jobs: int,
) -> np.ndarray:
    model = make_xgb(params, n_jobs=n_jobs)
    model.fit(
        train[features].to_numpy(dtype=float),
        train[f"log_y_vol_{horizon}"].to_numpy(dtype=float),
    )
    forecast = np.exp(model.predict(predict[features].to_numpy(dtype=float)))
    if not np.isfinite(forecast).all() or np.any(forecast <= 0):
        raise AssertionError("Invalid XGBoost forecast")
    return forecast


# -----------------------------------------------------------------------------
# CV tuning
# -----------------------------------------------------------------------------


def fold_qlike_record(
    split: FoldSplit,
    horizon: int,
    forecast: np.ndarray,
) -> float:
    actual = split.validation[f"y_vol_{horizon}"].to_numpy(dtype=float)
    return float(np.mean(qlike_losses(actual, forecast)))


def select_ridge_best(candidate_frame: pd.DataFrame) -> pd.Series:
    minimum = float(candidate_frame["mean_fold_qlike"].min())
    tied = candidate_frame.loc[
        np.abs(candidate_frame["mean_fold_qlike"] - minimum) <= TIE_ATOL
    ].copy()
    # Frozen tie rule: larger alpha.
    tied = tied.sort_values("alpha", ascending=False, kind="stable")
    return tied.iloc[0]


def xgb_tie_sort_columns(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.copy()
    result["_neg_reg_lambda"] = -result["reg_lambda"].astype(float)
    result["_neg_reg_alpha"] = -result["reg_alpha"].astype(float)
    return result.sort_values(
        ["max_depth", "n_estimators", "_neg_reg_lambda", "_neg_reg_alpha", "grid_index"],
        ascending=[True, True, True, True, True],
        kind="stable",
    )


def select_xgb_best(candidate_frame: pd.DataFrame) -> pd.Series:
    minimum = float(candidate_frame["mean_fold_qlike"].min())
    tied = candidate_frame.loc[
        np.abs(candidate_frame["mean_fold_qlike"] - minimum) <= TIE_ATOL
    ].copy()
    return xgb_tie_sort_columns(tied).iloc[0]


def best_prediction_rows(
    model_name: str,
    horizon: int,
    splits: list[FoldSplit],
    predict_fn,
) -> pd.DataFrame:
    frames: list[pd.DataFrame] = []
    for split in splits:
        forecast = np.asarray(predict_fn(split), dtype=float)
        actual = split.validation[f"y_vol_{horizon}"].to_numpy(dtype=float)
        frames.append(
            pd.DataFrame(
                {
                    "horizon": horizon,
                    "fold": split.name,
                    "model": model_name,
                    "date": split.validation["date"].dt.strftime("%Y-%m-%d"),
                    "label_end": split.validation[f"label_end_{horizon}"].dt.strftime("%Y-%m-%d"),
                    "actual_vol": actual,
                    "forecast_vol": forecast,
                    "qlike_loss": qlike_losses(actual, forecast),
                    "absolute_error": np.abs(forecast - actual),
                    "squared_error": np.square(forecast - actual),
                }
            )
        )
    return pd.concat(frames, ignore_index=True)


def tune_ridge_spec(
    horizon: int,
    info_set: str,
    splits: list[FoldSplit],
    cv_dir: Path,
    resume: bool,
) -> tuple[pd.DataFrame, dict[str, Any], pd.DataFrame]:
    model_name = f"Ridge-{info_set}"
    features = FEATURE_SETS[info_set]
    candidate_path = cv_dir / f"candidates_{model_name}_h{horizon}.csv"
    best_path = cv_dir / f"best_{model_name}_h{horizon}.json"
    pred_path = cv_dir / f"best_predictions_{model_name}_h{horizon}.csv"

    if resume and candidate_path.exists() and best_path.exists() and pred_path.exists():
        candidates = pd.read_csv(candidate_path)
        best = json.loads(best_path.read_text(encoding="utf-8"))
        predictions = pd.read_csv(pred_path)
        return candidates, best, predictions

    rows: list[dict[str, Any]] = []
    fold_columns = [f"qlike_{s.name}" for s in splits]

    for alpha in RIDGE_ALPHA_CANDIDATES:
        qlikes: list[float] = []
        for split in splits:
            forecast = fit_predict_ridge(split.train, split.validation, horizon, features, alpha)
            qlikes.append(fold_qlike_record(split, horizon, forecast))
        row: dict[str, Any] = {
            "model": model_name,
            "horizon": horizon,
            "info_set": info_set,
            "alpha": float(alpha),
            "mean_fold_qlike": float(np.mean(qlikes)),
        }
        row.update(dict(zip(fold_columns, qlikes)))
        rows.append(row)

    candidates = pd.DataFrame(rows)
    best_row = select_ridge_best(candidates)
    best_alpha = float(best_row["alpha"])
    best = {
        "model": model_name,
        "family": "Ridge",
        "horizon": horizon,
        "info_set": info_set,
        "target": f"log_y_vol_{horizon}",
        "selection_metric": "unweighted_mean_of_5_fold_QLIKE",
        "best_mean_fold_qlike": float(best_row["mean_fold_qlike"]),
        "params": {"alpha": best_alpha},
    }

    predictions = best_prediction_rows(
        model_name,
        horizon,
        splits,
        lambda split: fit_predict_ridge(
            split.train, split.validation, horizon, features, best_alpha
        ),
    )

    atomic_csv(candidates, candidate_path)
    json_dump(best_path, best)
    atomic_csv(predictions, pred_path)
    return candidates, best, predictions


def xgb_parameter_grid() -> list[dict[str, Any]]:
    keys = [
        "max_depth",
        "learning_rate",
        "subsample",
        "colsample_bytree",
        "n_estimators",
        "reg_alpha",
        "reg_lambda",
    ]
    values = [XGB_GRID[k] for k in keys]
    grid = [dict(zip(keys, combo)) for combo in itertools.product(*values)]
    if len(grid) != EXPECTED_XGB_COMBINATIONS:
        raise AssertionError(f"XGBoost grid changed: expected 864, got {len(grid)}")
    return grid


def tune_xgb_spec(
    horizon: int,
    info_set: str,
    splits: list[FoldSplit],
    cv_dir: Path,
    resume: bool,
    checkpoint_every: int,
    xgb_n_jobs: int,
) -> tuple[pd.DataFrame, dict[str, Any], pd.DataFrame]:
    model_name = f"XGB-{info_set}"
    features = FEATURE_SETS[info_set]
    candidate_path = cv_dir / f"candidates_{model_name}_h{horizon}.csv"
    best_path = cv_dir / f"best_{model_name}_h{horizon}.json"
    pred_path = cv_dir / f"best_predictions_{model_name}_h{horizon}.csv"

    if resume and candidate_path.exists() and best_path.exists() and pred_path.exists():
        candidates = pd.read_csv(candidate_path)
        # A complete spec must contain exactly the frozen grid size.
        if len(candidates) == EXPECTED_XGB_COMBINATIONS:
            best = json.loads(best_path.read_text(encoding="utf-8"))
            predictions = pd.read_csv(pred_path)
            return candidates, best, predictions

    existing = pd.DataFrame()
    completed_keys: set[str] = set()
    if resume and candidate_path.exists():
        existing = pd.read_csv(candidate_path)
        parameter_columns = list(XGB_GRID.keys())
        for _, row in existing.iterrows():
            params = {
                k: (int(row[k]) if k in {"max_depth", "n_estimators"} else float(row[k]))
                for k in parameter_columns
            }
            completed_keys.add(parameter_key(params))

    rows = existing.to_dict(orient="records") if not existing.empty else []
    fold_columns = [f"qlike_{s.name}" for s in splits]
    grid = xgb_parameter_grid()
    t0 = time.time()

    for grid_index, params in enumerate(grid):
        if parameter_key(params) in completed_keys:
            continue

        qlikes: list[float] = []
        for split in splits:
            forecast = fit_predict_xgb(
                split.train,
                split.validation,
                horizon,
                features,
                params,
                n_jobs=xgb_n_jobs,
            )
            qlikes.append(fold_qlike_record(split, horizon, forecast))

        row: dict[str, Any] = {
            "model": model_name,
            "horizon": horizon,
            "info_set": info_set,
            "grid_index": grid_index,
            **params,
            "mean_fold_qlike": float(np.mean(qlikes)),
        }
        row.update(dict(zip(fold_columns, qlikes)))
        rows.append(row)

        if checkpoint_every > 0 and len(rows) % checkpoint_every == 0:
            atomic_csv(pd.DataFrame(rows), candidate_path)
            elapsed = time.time() - t0
            print(
                f"[checkpoint] {model_name} h={horizon}: "
                f"{len(rows)}/{EXPECTED_XGB_COMBINATIONS} candidates, "
                f"elapsed={elapsed/60:.1f} min",
                flush=True,
            )

    candidates = pd.DataFrame(rows)
    # Remove any accidental duplicate parameter combinations from a resumed run.
    candidates = (
        candidates.sort_values("grid_index", kind="stable")
        .drop_duplicates(subset=list(XGB_GRID.keys()), keep="first")
        .reset_index(drop=True)
    )
    if len(candidates) != EXPECTED_XGB_COMBINATIONS:
        atomic_csv(candidates, candidate_path)
        raise AssertionError(
            f"{model_name} h={horizon}: incomplete XGB grid, "
            f"got {len(candidates)}, expected {EXPECTED_XGB_COMBINATIONS}"
        )

    best_row = select_xgb_best(candidates)
    best_params = {
        "max_depth": int(best_row["max_depth"]),
        "learning_rate": float(best_row["learning_rate"]),
        "subsample": float(best_row["subsample"]),
        "colsample_bytree": float(best_row["colsample_bytree"]),
        "n_estimators": int(best_row["n_estimators"]),
        "reg_alpha": float(best_row["reg_alpha"]),
        "reg_lambda": float(best_row["reg_lambda"]),
    }
    best = {
        "model": model_name,
        "family": "XGBoost",
        "horizon": horizon,
        "info_set": info_set,
        "target": f"log_y_vol_{horizon}",
        "selection_metric": "unweighted_mean_of_5_fold_QLIKE",
        "best_mean_fold_qlike": float(best_row["mean_fold_qlike"]),
        "grid_index": int(best_row["grid_index"]),
        "params": best_params,
    }

    predictions = best_prediction_rows(
        model_name,
        horizon,
        splits,
        lambda split: fit_predict_xgb(
            split.train,
            split.validation,
            horizon,
            features,
            best_params,
            n_jobs=xgb_n_jobs,
        ),
    )

    atomic_csv(candidates, candidate_path)
    json_dump(best_path, best)
    atomic_csv(predictions, pred_path)
    return candidates, best, predictions


def collect_cv_artifacts(cv_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    candidate_files = sorted(cv_dir.glob("candidates_*.csv"))
    best_files = sorted(cv_dir.glob("best_*.json"))
    pred_files = sorted(cv_dir.glob("best_predictions_*.csv"))

    candidates = pd.concat([pd.read_csv(p) for p in candidate_files], ignore_index=True) if candidate_files else pd.DataFrame()
    best_rows = []
    for p in best_files:
        item = json.loads(p.read_text(encoding="utf-8"))
        best_rows.append(
            {
                "model": item["model"],
                "family": item["family"],
                "horizon": item["horizon"],
                "info_set": item["info_set"],
                "target": item["target"],
                "selection_metric": item["selection_metric"],
                "best_mean_fold_qlike": item["best_mean_fold_qlike"],
                "params_json": json.dumps(item["params"], sort_keys=True),
            }
        )
    best_table = pd.DataFrame(best_rows)
    predictions = pd.concat([pd.read_csv(p) for p in pred_files], ignore_index=True) if pred_files else pd.DataFrame()
    return candidates, best_table, predictions


def require_all_best_params(cv_dir: Path) -> dict[tuple[int, str], dict[str, Any]]:
    result: dict[tuple[int, str], dict[str, Any]] = {}
    expected = []
    for horizon in HORIZONS:
        for family in ("Ridge", "XGB"):
            for info_set in ("A", "AB", "ABC"):
                model = f"{family}-{info_set}"
                path = cv_dir / f"best_{model}_h{horizon}.json"
                expected.append(path)
                if path.exists():
                    result[(horizon, model)] = json.loads(path.read_text(encoding="utf-8"))
    missing = [str(p) for p in expected if not p.exists()]
    if missing:
        raise FileNotFoundError(
            "OOS requires all 12 frozen Ridge/XGB best-parameter files. Missing:\n" + "\n".join(missing)
        )
    return result


# -----------------------------------------------------------------------------
# OOS monthly expanding-window experiment
# -----------------------------------------------------------------------------


def month_groups(oos: pd.DataFrame) -> list[tuple[str, pd.DataFrame]]:
    periods = oos["date"].dt.to_period("M")
    result: list[tuple[str, pd.DataFrame]] = []
    for period in sorted(periods.unique()):
        month = oos.loc[periods == period].copy()
        result.append((str(period), month))
    return result


def add_prediction_frame(
    frames: list[pd.DataFrame],
    horizon: int,
    model: str,
    month_label: str,
    train_n: int | None,
    train_label_end_max: pd.Timestamp | None,
    month: pd.DataFrame,
    forecast: np.ndarray,
) -> None:
    actual = month[f"y_vol_{horizon}"].to_numpy(dtype=float)
    forecast = np.asarray(forecast, dtype=float)
    if len(forecast) != len(month):
        raise AssertionError(f"{model}, h={horizon}, {month_label}: forecast length mismatch")
    if not np.isfinite(forecast).all() or np.any(forecast <= 0):
        raise AssertionError(f"{model}, h={horizon}, {month_label}: invalid forecast")
    frames.append(
        pd.DataFrame(
            {
                "horizon": horizon,
                "month": month_label,
                "model": model,
                "date": month["date"].dt.strftime("%Y-%m-%d"),
                "label_end": month[f"label_end_{horizon}"].dt.strftime("%Y-%m-%d"),
                "train_n": train_n,
                "train_label_end_max": None if train_label_end_max is None else train_label_end_max.strftime("%Y-%m-%d"),
                "actual_vol": actual,
                "forecast_vol": forecast,
                "qlike_loss": qlike_losses(actual, forecast),
                "absolute_error": np.abs(forecast - actual),
                "squared_error": np.square(forecast - actual),
            }
        )
    )


def run_oos_for_horizon(
    frame: pd.DataFrame,
    horizon: int,
    best_params: dict[tuple[int, str], dict[str, Any]],
    xgb_n_jobs: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    label_end = f"label_end_{horizon}"
    oos_flag = f"oos_{horizon}"
    oos = frame.loc[
        frame[oos_flag]
        & (frame["date"] >= OOS_START)
        & (frame["date"] <= OOS_END)
    ].copy()
    if oos.empty:
        raise AssertionError(f"h={horizon}: empty OOS sample")

    prediction_frames: list[pd.DataFrame] = []
    audit_rows: list[dict[str, Any]] = []

    # Persistence is formula-based and does not need monthly fitting, but we still
    # emit predictions month-by-month so every model has exactly the same dates.
    for month_label, month in month_groups(oos):
        tau = month["date"].min()
        train = frame.loc[(frame["date"] < tau) & (frame[label_end] < tau)].copy()
        if train.empty:
            raise AssertionError(f"h={horizon}, {month_label}: empty expanding training set")
        if train[label_end].max() >= tau:
            raise AssertionError(f"h={horizon}, {month_label}: training label not mature")

        audit_rows.append(
            {
                "horizon": horizon,
                "month": month_label,
                "tau_first_oos_date": tau.strftime("%Y-%m-%d"),
                "train_n": len(train),
                "train_first_date": train["date"].min().strftime("%Y-%m-%d"),
                "train_last_date": train["date"].max().strftime("%Y-%m-%d"),
                "train_label_end_max": train[label_end].max().strftime("%Y-%m-%d"),
                "predict_n": len(month),
                "predict_first_date": month["date"].min().strftime("%Y-%m-%d"),
                "predict_last_date": month["date"].max().strftime("%Y-%m-%d"),
                "training_labels_mature": bool(train[label_end].max() < tau),
                "single_refit_per_calendar_month": True,
            }
        )

        train_n = len(train)
        train_label_end_max = train[label_end].max()

        # M1 Persistence
        persistence = month[PERSISTENCE_FEATURE[horizon]].to_numpy(dtype=float)
        add_prediction_frame(
            prediction_frames,
            horizon,
            "Persistence",
            month_label,
            None,
            None,
            month,
            persistence,
        )

        # M2 Multi-scale Linear
        multiscale = fit_predict_multiscale_linear(train, month, horizon)
        add_prediction_frame(
            prediction_frames,
            horizon,
            "Multi-scale Linear",
            month_label,
            train_n,
            train_label_end_max,
            month,
            multiscale,
        )

        # M3-M5 Ridge A/AB/ABC
        for info_set in ("A", "AB", "ABC"):
            model_name = f"Ridge-{info_set}"
            alpha = float(best_params[(horizon, model_name)]["params"]["alpha"])
            forecast = fit_predict_ridge(
                train,
                month,
                horizon,
                FEATURE_SETS[info_set],
                alpha,
            )
            add_prediction_frame(
                prediction_frames,
                horizon,
                model_name,
                month_label,
                train_n,
                train_label_end_max,
                month,
                forecast,
            )

        # M6-M8 XGB A/AB/ABC
        for info_set in ("A", "AB", "ABC"):
            model_name = f"XGB-{info_set}"
            params = dict(best_params[(horizon, model_name)]["params"])
            forecast = fit_predict_xgb(
                train,
                month,
                horizon,
                FEATURE_SETS[info_set],
                params,
                n_jobs=xgb_n_jobs,
            )
            add_prediction_frame(
                prediction_frames,
                horizon,
                model_name,
                month_label,
                train_n,
                train_label_end_max,
                month,
                forecast,
            )

    predictions = pd.concat(prediction_frames, ignore_index=True)
    audit = pd.DataFrame(audit_rows)

    expected_models = {
        "Persistence",
        "Multi-scale Linear",
        "Ridge-A",
        "Ridge-AB",
        "Ridge-ABC",
        "XGB-A",
        "XGB-AB",
        "XGB-ABC",
    }
    if set(predictions["model"].unique()) != expected_models:
        raise AssertionError(f"h={horizon}: missing OOS models")

    reference_dates = set(oos["date"].dt.strftime("%Y-%m-%d"))
    for model, group in predictions.groupby("model"):
        dates = set(group["date"])
        if dates != reference_dates:
            raise AssertionError(f"h={horizon}: OOS date mismatch for {model}")
        if group["date"].duplicated().any():
            raise AssertionError(f"h={horizon}: duplicate OOS predictions for {model}")

    return predictions, audit


# -----------------------------------------------------------------------------
# OOS metrics, information increments, and DM tests
# -----------------------------------------------------------------------------


def oos_metrics(predictions: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for horizon in HORIZONS:
        subset = predictions.loc[predictions["horizon"].eq(horizon)].copy()
        persistence = subset.loc[subset["model"].eq("Persistence")].sort_values("date")
        denom = float(persistence["squared_error"].sum())
        if denom <= 0 or not np.isfinite(denom):
            raise AssertionError(f"h={horizon}: invalid Persistence SSE for OOS R^2")

        for model, group in subset.groupby("model", sort=False):
            group = group.sort_values("date")
            rows.append(
                {
                    "horizon": horizon,
                    "model": model,
                    "n": len(group),
                    "qlike": float(group["qlike_loss"].mean()),
                    "mae": float(group["absolute_error"].mean()),
                    "rmse": float(np.sqrt(group["squared_error"].mean())),
                    "r2_oos_vs_persistence": float(1.0 - group["squared_error"].sum() / denom),
                }
            )
    return pd.DataFrame(rows)


def information_increment_table(metrics: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for horizon in HORIZONS:
        sub = metrics.loc[metrics["horizon"].eq(horizon)].set_index("model")
        for family in ("Ridge", "XGB"):
            for old_set, new_set in (("A", "AB"), ("AB", "ABC")):
                old_model = f"{family}-{old_set}"
                new_model = f"{family}-{new_set}"
                for metric in ("qlike", "mae", "rmse"):
                    old_loss = float(sub.loc[old_model, metric])
                    new_loss = float(sub.loc[new_model, metric])
                    improvement = old_loss - new_loss
                    rows.append(
                        {
                            "horizon": horizon,
                            "family": family,
                            "transition": f"{old_set}->{new_set}",
                            "metric": metric,
                            "old_model": old_model,
                            "new_model": new_model,
                            "old_loss": old_loss,
                            "new_loss": new_loss,
                            "delta_loss_old_minus_new": improvement,
                            "positive_means_incremental_improvement": improvement > 0,
                            "relative_improvement_pct": float(100.0 * improvement / old_loss) if old_loss != 0 else np.nan,
                        }
                    )
    return pd.DataFrame(rows)


def newey_west_dm(loss1: np.ndarray, loss2: np.ndarray, lag: int) -> dict[str, float]:
    """Two-sided DM test with Bartlett/Newey-West HAC, no post-hoc small-sample correction."""
    l1 = np.asarray(loss1, dtype=float)
    l2 = np.asarray(loss2, dtype=float)
    if l1.shape != l2.shape:
        raise ValueError("DM loss vectors must have the same shape")
    if not np.isfinite(l1).all() or not np.isfinite(l2).all():
        raise ValueError("DM losses must be finite")
    n = len(l1)
    if n <= lag + 1:
        raise ValueError(f"DM sample too small for lag={lag}")

    d = l1 - l2
    mean_d = float(np.mean(d))
    centered = d - mean_d
    gamma0 = float(np.dot(centered, centered) / n)
    lrv = gamma0
    for ell in range(1, lag + 1):
        gamma = float(np.dot(centered[ell:], centered[:-ell]) / n)
        weight = 1.0 - ell / (lag + 1.0)
        lrv += 2.0 * weight * gamma

    # Numerical safeguard only. A meaningfully negative LRV signals a coding/data problem.
    if lrv < -1e-14:
        raise AssertionError(f"Negative Newey-West long-run variance: {lrv}")
    lrv = max(lrv, 0.0)
    if lrv == 0.0:
        dm_stat = math.copysign(math.inf, mean_d) if mean_d != 0 else 0.0
        p_value = 0.0 if mean_d != 0 else 1.0
    else:
        se = math.sqrt(lrv / n)
        dm_stat = mean_d / se
        p_value = 2.0 * float(norm.sf(abs(dm_stat)))

    return {
        "n": n,
        "hac_lag": lag,
        "mean_loss_diff_model1_minus_model2": mean_d,
        "dm_stat": float(dm_stat),
        "p_value_two_sided": float(p_value),
        "newey_west_long_run_variance": float(lrv),
    }


def aligned_loss_pair(
    predictions: pd.DataFrame,
    horizon: int,
    model1: str,
    model2: str,
) -> tuple[np.ndarray, np.ndarray]:
    a = predictions.loc[
        predictions["horizon"].eq(horizon) & predictions["model"].eq(model1),
        ["date", "qlike_loss"],
    ].rename(columns={"qlike_loss": "loss1"})
    b = predictions.loc[
        predictions["horizon"].eq(horizon) & predictions["model"].eq(model2),
        ["date", "qlike_loss"],
    ].rename(columns={"qlike_loss": "loss2"})
    merged = a.merge(b, on="date", how="inner", validate="one_to_one").sort_values("date")
    if len(merged) != len(a) or len(merged) != len(b):
        raise AssertionError(f"DM date alignment failure: h={horizon}, {model1}, {model2}")
    return merged["loss1"].to_numpy(dtype=float), merged["loss2"].to_numpy(dtype=float)


def dm_table(predictions: pd.DataFrame, supplementary: bool) -> pd.DataFrame:
    core_pairs = [
        ("Ridge-A", "Ridge-AB"),
        ("Ridge-AB", "Ridge-ABC"),
        ("XGB-A", "XGB-AB"),
        ("XGB-AB", "XGB-ABC"),
    ]
    supplementary_pairs = [
        ("Persistence", "Multi-scale Linear"),
        ("Persistence", "Ridge-A"),
        ("Persistence", "Ridge-AB"),
        ("Persistence", "Ridge-ABC"),
        ("Persistence", "XGB-A"),
        ("Persistence", "XGB-AB"),
        ("Persistence", "XGB-ABC"),
        ("Multi-scale Linear", "Ridge-A"),
        ("Multi-scale Linear", "Ridge-AB"),
        ("Multi-scale Linear", "Ridge-ABC"),
        ("Multi-scale Linear", "XGB-A"),
        ("Multi-scale Linear", "XGB-AB"),
        ("Multi-scale Linear", "XGB-ABC"),
    ]
    pairs = supplementary_pairs if supplementary else core_pairs
    rows: list[dict[str, Any]] = []
    for horizon in HORIZONS:
        lag = horizon - 1
        for model1, model2 in pairs:
            l1, l2 = aligned_loss_pair(predictions, horizon, model1, model2)
            result = newey_west_dm(l1, l2, lag=lag)
            mean_diff = result["mean_loss_diff_model1_minus_model2"]
            rows.append(
                {
                    "horizon": horizon,
                    "model1": model1,
                    "model2": model2,
                    "loss": "QLIKE",
                    **result,
                    "lower_mean_loss": model1 if mean_diff < 0 else (model2 if mean_diff > 0 else "tie"),
                    "significant_at_5pct": result["p_value_two_sided"] < 0.05,
                }
            )
    return pd.DataFrame(rows)


# -----------------------------------------------------------------------------
# Main orchestration
# -----------------------------------------------------------------------------


def protocol_metadata(data_dir: Path, xgb_n_jobs: int) -> dict[str, Any]:
    input_files = []
    for h in HORIZONS:
        input_files += [
            data_dir / f"model_dataset_h{h}_v2.csv",
            data_dir / f"cv_folds_h{h}_v2.csv",
        ]
    missing = [str(p) for p in input_files if not p.exists()]
    if missing:
        raise FileNotFoundError("Missing frozen inputs:\n" + "\n".join(missing))

    return {
        "protocol_name": PROTOCOL_NAME,
        "global_seed": GLOBAL_SEED,
        "horizons": list(HORIZONS),
        "oos_start": OOS_START.strftime("%Y-%m-%d"),
        "oos_end": OOS_END.strftime("%Y-%m-%d"),
        "cv_folds": [
            {"name": n, "start": s.strftime("%Y-%m-%d"), "end": e.strftime("%Y-%m-%d")}
            for n, s, e in CV_FOLDS
        ],
        "feature_counts": {k: len(v) for k, v in FEATURE_SETS.items()},
        "feature_sets": FEATURE_SETS,
        "fit_target": "log_y_vol_h for all fitted regression models",
        "inverse_transform": "forecast_vol = exp(predicted_log_vol)",
        "cv_selection_metric": "unweighted arithmetic mean of five fold-level QLIKE values",
        "ridge_alphas": RIDGE_ALPHA_CANDIDATES,
        "xgb_grid": XGB_GRID,
        "xgb_grid_size": EXPECTED_XGB_COMBINATIONS,
        "xgb_objective": "reg:squarederror",
        "xgb_early_stopping": False,
        "xgb_n_jobs": xgb_n_jobs,
        "dm": {
            "loss": "QLIKE",
            "hac": "Newey-West/Bartlett",
            "lag_rule": "horizon - 1",
            "two_sided": True,
            "alpha": 0.05,
        },
        "software": {
            "python": sys.version,
            "platform": platform.platform(),
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "scipy": scipy.__version__,
            "scikit_learn": sklearn.__version__,
            "xgboost": xgboost.__version__,
        },
        "input_sha256": {p.name: sha256_file(p) for p in input_files},
    }


def run_cv_family(
    family: str,
    datasets: dict[int, pd.DataFrame],
    split_map: dict[int, list[FoldSplit]],
    cv_dir: Path,
    resume: bool,
    checkpoint_every: int,
    xgb_n_jobs: int,
) -> None:
    family = family.lower()
    for horizon in HORIZONS:
        for info_set in ("A", "AB", "ABC"):
            if family == "ridge":
                print(f"[CV] Ridge-{info_set}, h={horizon}", flush=True)
                _, best, _ = tune_ridge_spec(
                    horizon,
                    info_set,
                    split_map[horizon],
                    cv_dir,
                    resume=resume,
                )
            elif family == "xgb":
                print(f"[CV] XGB-{info_set}, h={horizon}", flush=True)
                _, best, _ = tune_xgb_spec(
                    horizon,
                    info_set,
                    split_map[horizon],
                    cv_dir,
                    resume=resume,
                    checkpoint_every=checkpoint_every,
                    xgb_n_jobs=xgb_n_jobs,
                )
            else:
                raise ValueError(f"Unknown family: {family}")
            print(
                f"      best={best['params']} | mean 5-fold QLIKE={best['best_mean_fold_qlike']:.10g}",
                flush=True,
            )


def write_combined_cv_outputs(cv_dir: Path) -> None:
    candidates, best_table, predictions = collect_cv_artifacts(cv_dir)
    if not candidates.empty:
        atomic_csv(candidates, cv_dir / "cv_all_candidates.csv")
    if not best_table.empty:
        best_table = best_table.sort_values(["horizon", "family", "info_set"], kind="stable")
        atomic_csv(best_table, cv_dir / "cv_best_params.csv")
    if not predictions.empty:
        predictions = predictions.sort_values(["horizon", "model", "date"], kind="stable")
        atomic_csv(predictions, cv_dir / "cv_best_predictions.csv")


def run_oos(
    datasets: dict[int, pd.DataFrame],
    cv_dir: Path,
    oos_dir: Path,
    xgb_n_jobs: int,
) -> None:
    best_params = require_all_best_params(cv_dir)
    prediction_frames: list[pd.DataFrame] = []
    audit_frames: list[pd.DataFrame] = []

    for horizon in HORIZONS:
        print(f"[OOS] h={horizon}: monthly expanding-window 2023-01 ... 2026-08", flush=True)
        predictions, audit = run_oos_for_horizon(
            datasets[horizon],
            horizon,
            best_params,
            xgb_n_jobs=xgb_n_jobs,
        )
        prediction_frames.append(predictions)
        audit_frames.append(audit)

    predictions = pd.concat(prediction_frames, ignore_index=True)
    audit = pd.concat(audit_frames, ignore_index=True)
    metrics = oos_metrics(predictions)
    increments = information_increment_table(metrics)
    dm_core = dm_table(predictions, supplementary=False)
    dm_supp = dm_table(predictions, supplementary=True)

    oos_dir.mkdir(parents=True, exist_ok=True)
    atomic_csv(predictions, oos_dir / "oos_predictions.csv")
    atomic_csv(audit, oos_dir / "oos_monthly_training_audit.csv")
    atomic_csv(metrics, oos_dir / "oos_metrics.csv")
    atomic_csv(increments, oos_dir / "information_increment.csv")
    atomic_csv(dm_core, oos_dir / "dm_tests_core.csv")
    atomic_csv(dm_supp, oos_dir / "dm_tests_supplementary.csv")

    # Strong final gates.
    if not audit["training_labels_mature"].all():
        raise AssertionError("OOS training-label maturity audit failed")
    for horizon in HORIZONS:
        n_by_model = predictions.loc[predictions["horizon"].eq(horizon)].groupby("model").size()
        if n_by_model.nunique() != 1:
            raise AssertionError(f"h={horizon}: models do not have identical OOS sample counts")


def self_test() -> None:
    # QLIKE must be zero for perfect forecasts.
    a = np.array([0.2, 0.3, 0.5])
    assert np.allclose(qlike_losses(a, a), 0.0)

    # DM with model2 uniformly better should have positive mean(model1-model2).
    l1 = np.linspace(0.2, 0.4, 100)
    l2 = l1 - 0.05 + 0.005 * np.sin(np.arange(100))
    dm = newey_west_dm(l1, l2, lag=4)
    assert dm["mean_loss_diff_model1_minus_model2"] > 0

    # Frozen XGB grid size.
    assert len(xgb_parameter_grid()) == 864

    # Ridge tie rule: larger alpha.
    rf = pd.DataFrame({"alpha": [1.0, 10.0], "mean_fold_qlike": [0.2, 0.2]})
    assert float(select_ridge_best(rf)["alpha"]) == 10.0

    print("SELF-TEST PASS")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=PROTOCOL_NAME)
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=Path("."),
        help="Directory containing frozen V2 model_dataset_h*_v2.csv and cv_folds_h*_v2.csv",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("main_experiment_v1"),
        help="Output directory. Refuses to overwrite unless --resume is supplied.",
    )
    parser.add_argument(
        "--stage",
        choices=["ridge-cv", "xgb-cv", "cv", "oos", "all", "self-test"],
        default="all",
        help="Execution stage. Staging changes runtime only, not the frozen protocol.",
    )
    parser.add_argument(
        "--resume",
        action="store_true",
        help="Resume a prior run in the same output directory and reuse completed CV spec artifacts.",
    )
    parser.add_argument(
        "--checkpoint-every",
        type=int,
        default=25,
        help="For XGBoost CV, atomically checkpoint candidate results every N completed candidates.",
    )
    parser.add_argument(
        "--xgb-n-jobs",
        type=int,
        default=1,
        help="Threads inside each XGBoost fit. Default 1 for strongest reproducibility.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    if args.stage == "self-test":
        self_test()
        return

    data_dir = args.data_dir.expanduser().resolve()
    output_dir = args.output_dir.expanduser().resolve()
    cv_dir = output_dir / "cv"
    oos_dir = output_dir / "oos"

    if output_dir.exists() and not args.resume:
        raise FileExistsError(
            f"Output directory already exists: {output_dir}\n"
            "Use a new output directory, or pass --resume only when intentionally continuing the same frozen run."
        )
    output_dir.mkdir(parents=True, exist_ok=True)
    cv_dir.mkdir(parents=True, exist_ok=True)

    metadata = protocol_metadata(data_dir, xgb_n_jobs=args.xgb_n_jobs)
    metadata_path = output_dir / "protocol_metadata.json"
    if metadata_path.exists() and args.resume:
        old = json.loads(metadata_path.read_text(encoding="utf-8"))
        # Input hashes and protocol-critical constants must not change under resume.
        critical = [
            "protocol_name",
            "global_seed",
            "horizons",
            "oos_start",
            "oos_end",
            "cv_folds",
            "feature_sets",
            "ridge_alphas",
            "xgb_grid",
            "xgb_grid_size",
            "input_sha256",
            "xgb_n_jobs",
        ]
        for key in critical:
            if old.get(key) != metadata.get(key):
                raise AssertionError(
                    f"Resume refused: protocol/input metadata changed for key '{key}'. "
                    "Use a new output directory/version."
                )
    else:
        json_dump(metadata_path, metadata)

    datasets: dict[int, pd.DataFrame] = {}
    split_map: dict[int, list[FoldSplit]] = {}
    audit_frames: list[pd.DataFrame] = []
    for horizon in HORIZONS:
        frame = load_dataset(data_dir, horizon)
        splits = build_calendar_splits(frame, horizon)
        artifact_audit = assert_cv_artifact_matches(data_dir, horizon, splits)
        datasets[horizon] = frame
        split_map[horizon] = splits
        audit_frames.append(artifact_audit)

    atomic_csv(pd.concat(audit_frames, ignore_index=True), output_dir / "cv_artifact_consistency_audit.csv")

    if args.stage in {"ridge-cv", "cv", "all"}:
        run_cv_family(
            "ridge",
            datasets,
            split_map,
            cv_dir,
            resume=args.resume,
            checkpoint_every=args.checkpoint_every,
            xgb_n_jobs=args.xgb_n_jobs,
        )
        write_combined_cv_outputs(cv_dir)

    if args.stage in {"xgb-cv", "cv", "all"}:
        run_cv_family(
            "xgb",
            datasets,
            split_map,
            cv_dir,
            resume=args.resume,
            checkpoint_every=args.checkpoint_every,
            xgb_n_jobs=args.xgb_n_jobs,
        )
        write_combined_cv_outputs(cv_dir)

    if args.stage in {"oos", "all"}:
        write_combined_cv_outputs(cv_dir)
        run_oos(datasets, cv_dir, oos_dir, xgb_n_jobs=args.xgb_n_jobs)

    print(f"\nMAIN EXPERIMENT STAGE PASS: {args.stage}")
    print(f"Output: {output_dir}")


if __name__ == "__main__":
    main()
