"""Calendar CV, label maturity, paper-aligned benchmarks, and metrics."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class CalendarFold:
    name: str
    start: pd.Timestamp
    end: pd.Timestamp


def prepare_temporal_frame(frame: pd.DataFrame, horizon: int) -> pd.DataFrame:
    required = {
        "date", f"label_end_{horizon}", f"eligible_continuous_{horizon}",
        f"y_vol_{horizon}", f"log_y_vol_{horizon}",
    }
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    result = frame.loc[frame[f"eligible_continuous_{horizon}"].astype(bool)].copy()
    result["date"] = pd.to_datetime(result["date"], errors="raise")
    result[f"label_end_{horizon}"] = pd.to_datetime(
        result[f"label_end_{horizon}"].astype(str).str.slice(0, 10), errors="raise"
    )
    result = result.sort_values("date").reset_index(drop=True)
    if result["date"].duplicated().any():
        raise AssertionError("Eligible sample contains duplicate dates")
    return result


def build_calendar_splits(
    frame: pd.DataFrame,
    horizon: int,
    folds: Iterable[CalendarFold],
    oos_start: pd.Timestamp,
) -> list[tuple[CalendarFold, pd.DataFrame, pd.DataFrame]]:
    label_end = f"label_end_{horizon}"
    cutoff = pd.Timestamp(oos_start)
    splits = []
    for fold in folds:
        train = frame.loc[(frame["date"] < fold.start) & (frame[label_end] < fold.start)].copy()
        validation = frame.loc[
            (frame["date"] >= fold.start)
            & (frame["date"] <= fold.end)
            & (frame[label_end] <= fold.end)
            & (frame[label_end] < cutoff)
        ].copy()
        if train.empty or validation.empty:
            raise AssertionError(f"Empty train/validation sample in {fold.name}, h={horizon}")
        splits.append((fold, train, validation))
    return splits


def fit_multiscale_linear(
    train: pd.DataFrame,
    validation: pd.DataFrame,
    horizon: int,
    volatility_features: list[str],
) -> np.ndarray:
    expected = [
        "I_daily_squared_return_vol_5",
        "I_daily_squared_return_vol_22",
        "I_daily_squared_return_vol_66",
    ]
    if volatility_features != expected:
        raise AssertionError(f"Multi-scale Linear feature set must equal {expected}")
    x_train = np.log(train[volatility_features].to_numpy(dtype=float))
    x_valid = np.log(validation[volatility_features].to_numpy(dtype=float))
    if not np.isfinite(x_train).all() or not np.isfinite(x_valid).all():
        raise AssertionError("Multi-scale log-volatility inputs must be positive and finite")
    design_train = np.column_stack([np.ones(len(train)), x_train])
    design_valid = np.column_stack([np.ones(len(validation)), x_valid])
    coefficients, *_ = np.linalg.lstsq(
        design_train,
        train[f"log_y_vol_{horizon}"].to_numpy(dtype=float),
        rcond=None,
    )
    return np.exp(design_valid @ coefficients)


def qlike_variance(actual_vol: np.ndarray, forecast_vol: np.ndarray) -> float:
    actual = np.asarray(actual_vol, dtype=float)
    forecast = np.asarray(forecast_vol, dtype=float)
    if np.any(actual <= 0) or np.any(forecast <= 0):
        raise ValueError("QLIKE requires strictly positive volatilities")
    ratio = np.square(actual) / np.square(forecast)
    return float(np.mean(ratio - np.log(ratio) - 1.0))


def metric_record(actual: np.ndarray, forecast: np.ndarray) -> dict[str, float]:
    errors = np.asarray(forecast) - np.asarray(actual)
    return {
        "rmse": float(np.sqrt(np.mean(np.square(errors)))),
        "mae": float(np.mean(np.abs(errors))),
        "qlike": qlike_variance(actual, forecast),
    }
