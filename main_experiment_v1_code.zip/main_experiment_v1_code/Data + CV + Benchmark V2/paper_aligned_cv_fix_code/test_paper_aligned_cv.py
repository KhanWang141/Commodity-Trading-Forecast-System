from __future__ import annotations

import numpy as np
import pandas as pd

from paper_aligned_cv import CalendarFold, build_calendar_splits, metric_record


def test_training_labels_mature_before_validation():
    frame = pd.DataFrame(
        {
            "date": pd.to_datetime(["2020-06-20", "2020-06-25", "2020-07-01"]),
            "label_end_5": pd.to_datetime(["2020-06-29", "2020-07-02", "2020-07-08"]),
        }
    )
    fold = CalendarFold("2020H2", pd.Timestamp("2020-07-01"), pd.Timestamp("2020-12-31"))
    _, train, _ = build_calendar_splits(frame, 5, [fold], pd.Timestamp("2023-01-01"))[0]
    assert train["date"].tolist() == [pd.Timestamp("2020-06-20")]


def test_metric_record_is_finite():
    result = metric_record(np.array([0.2, 0.3]), np.array([0.21, 0.29]))
    assert all(np.isfinite(value) for value in result.values())


def test_validation_labels_stay_inside_fold():
    frame = pd.DataFrame(
        {
            "date": pd.to_datetime([
                "2020-06-20",
                "2020-12-23",
                "2020-12-24",
                "2020-12-25",
                "2020-12-31",
            ]),
            "label_end_5": pd.to_datetime([
                "2020-06-29",
                "2020-12-30",
                "2020-12-31",
                "2021-01-04",
                "2021-01-08",
            ]),
        }
    )
    fold = CalendarFold("2020H2", pd.Timestamp("2020-07-01"), pd.Timestamp("2020-12-31"))
    _, _, validation = build_calendar_splits(
        frame, 5, [fold], pd.Timestamp("2023-01-01")
    )[0]
    assert validation["date"].tolist() == [
        pd.Timestamp("2020-12-23"),
        pd.Timestamp("2020-12-24"),
    ]
    assert validation["label_end_5"].max() <= fold.end
