"""Generate paper-aligned half-year CV benchmark CSV artifacts."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from paper_aligned_cv import (
    CalendarFold,
    build_calendar_splits,
    fit_multiscale_linear,
    metric_record,
    prepare_temporal_frame,
)


FOLDS = [
    CalendarFold("2020H2", pd.Timestamp("2020-07-01"), pd.Timestamp("2020-12-31")),
    CalendarFold("2021H1", pd.Timestamp("2021-01-01"), pd.Timestamp("2021-06-30")),
    CalendarFold("2021H2", pd.Timestamp("2021-07-01"), pd.Timestamp("2021-12-31")),
    CalendarFold("2022H1", pd.Timestamp("2022-01-01"), pd.Timestamp("2022-06-30")),
    CalendarFold("2022H2", pd.Timestamp("2022-07-01"), pd.Timestamp("2022-12-31")),
]
OOS_START = pd.Timestamp("2023-01-01")
VOLATILITY_FEATURES = [
    "I_daily_squared_return_vol_5",
    "I_daily_squared_return_vol_22",
    "I_daily_squared_return_vol_66",
]
PERSISTENCE_FEATURES = {
    5: "I_daily_squared_return_vol_5",
    20: "I_daily_squared_return_vol_22",
}


def _gate(rows: list[dict], horizon: int, fold: str, gate: str, passed: bool) -> None:
    rows.append(
        {
            "horizon": horizon,
            "fold": fold,
            "gate": gate,
            "status": "PASS" if passed else "FAIL",
            "detail": "paper-aligned protocol assertion",
        }
    )




def _assert_cv_artifact_matches(
    data_dir: Path,
    horizon: int,
    splits: list[tuple[CalendarFold, pd.DataFrame, pd.DataFrame]],
) -> None:
    """Require generated cv_folds CSV to match benchmark split dates exactly."""
    path = data_dir / f"cv_folds_h{horizon}_v2.csv"
    if not path.exists():
        raise FileNotFoundError(
            f"Missing {path.name}; rebuild the paper-aligned data package first."
        )

    artifact = pd.read_csv(path)
    required = {"date", "fold_id", "role"}
    missing = sorted(required.difference(artifact.columns))
    if missing:
        raise ValueError(f"{path.name} is missing required columns: {missing}")
    artifact["date"] = pd.to_datetime(artifact["date"], errors="raise").dt.normalize()

    for fold, train, validation in splits:
        for role, expected in [("train", train), ("validation", validation)]:
            stored_dates = set(
                artifact.loc[
                    artifact["fold_id"].eq(fold.name) & artifact["role"].eq(role),
                    "date",
                ]
            )
            expected_dates = set(pd.to_datetime(expected["date"]).dt.normalize())
            if stored_dates != expected_dates:
                only_in_artifact = sorted(stored_dates - expected_dates)
                only_in_benchmark = sorted(expected_dates - stored_dates)
                raise AssertionError(
                    f"CV artifact mismatch for h={horizon}, {fold.name}, {role}: "
                    f"only_in_cv_folds={len(only_in_artifact)}, "
                    f"only_in_benchmark={len(only_in_benchmark)}"
                )


def run(data_dir: Path, output_dir: Path) -> Path:
    if output_dir.exists():
        raise FileExistsError(f"Refusing to overwrite existing output: {output_dir}")
    output_dir.mkdir(parents=True)
    fold_rows: list[dict] = []
    audit_rows: list[dict] = []
    prediction_frames: list[pd.DataFrame] = []
    metric_rows: list[dict] = []

    for horizon in [5, 20]:
        dataset = pd.read_csv(data_dir / f"model_dataset_h{horizon}_v2.csv")
        frame = prepare_temporal_frame(dataset, horizon)
        splits = build_calendar_splits(frame, horizon, FOLDS, OOS_START)
        _assert_cv_artifact_matches(data_dir, horizon, splits)
        persistence_feature = PERSISTENCE_FEATURES[horizon]
        for fold, train, validation in splits:
            label_end = f"label_end_{horizon}"
            fold_rows.append(
                {
                    "horizon": horizon,
                    "fold": fold.name,
                    "validation_start": fold.start.date(),
                    "validation_end": fold.end.date(),
                    "train_n": len(train),
                    "validation_n": len(validation),
                    "train_first": train["date"].min().date(),
                    "train_last": train["date"].max().date(),
                    "train_label_end_max": train[label_end].max().date(),
                    "validation_first": validation["date"].min().date(),
                    "validation_last": validation["date"].max().date(),
                    "validation_label_end_max": validation[label_end].max().date(),
                }
            )
            gates = {
                "train_before_validation": train["date"].max() < validation["date"].min(),
                "training_labels_mature": train[label_end].max() < validation["date"].min(),
                "validation_labels_inside_fold": validation[label_end].max() <= fold.end,
                "validation_labels_pre_oos": validation[label_end].max() < OOS_START,
                "no_date_overlap": set(train["date"]).isdisjoint(validation["date"]),
                "persistence_horizon_matched": persistence_feature
                == {5: "I_daily_squared_return_vol_5", 20: "I_daily_squared_return_vol_22"}[horizon],
                "multiscale_volatility_only": VOLATILITY_FEATURES
                == [
                    "I_daily_squared_return_vol_5",
                    "I_daily_squared_return_vol_22",
                    "I_daily_squared_return_vol_66",
                ],
                "strict_positive_target": (validation[f"y_vol_{horizon}"] > 0).all(),
            }
            for name, passed in gates.items():
                _gate(audit_rows, horizon, fold.name, name, bool(passed))

            actual = validation[f"y_vol_{horizon}"].to_numpy(dtype=float)
            forecasts = {
                "Persistence": validation[persistence_feature].to_numpy(dtype=float),
                "Multi-scale Linear": fit_multiscale_linear(
                    train, validation, horizon, VOLATILITY_FEATURES
                ),
            }
            for model, forecast in forecasts.items():
                predictions = pd.DataFrame(
                    {
                        "horizon": horizon,
                        "fold": fold.name,
                        "model": model,
                        "date": validation["date"].dt.date.astype(str),
                        "label_end": validation[label_end].dt.date.astype(str),
                        "actual_vol": actual,
                        "forecast_vol": forecast,
                    }
                )
                prediction_frames.append(predictions)
                metric_rows.append(
                    {
                        "horizon": horizon,
                        "fold": fold.name,
                        "model": model,
                        "n": len(predictions),
                        **metric_record(actual, forecast),
                    }
                )

    folds_frame = pd.DataFrame(fold_rows)
    audit_frame = pd.DataFrame(audit_rows)
    predictions = pd.concat(prediction_frames, ignore_index=True)
    metrics = pd.DataFrame(metric_rows)
    pooled_rows = []
    for (horizon, model), group in predictions.groupby(["horizon", "model"], sort=False):
        pooled_rows.append(
            {
                "horizon": horizon,
                "fold": "POOLED",
                "model": model,
                "n": len(group),
                **metric_record(group["actual_vol"].to_numpy(), group["forecast_vol"].to_numpy()),
            }
        )
    metrics = pd.concat([metrics, pd.DataFrame(pooled_rows)], ignore_index=True)
    if not audit_frame["status"].eq("PASS").all():
        raise AssertionError("One or more zero-leakage benchmark gates failed")

    folds_frame.to_csv(output_dir / "cv_fold_summary_v2.csv", index=False, encoding="utf-8-sig")
    audit_frame.to_csv(output_dir / "benchmark_leakage_audit_v2.csv", index=False, encoding="utf-8-sig")
    predictions.to_csv(output_dir / "benchmark_predictions_v2.csv", index=False, encoding="utf-8-sig")
    metrics.to_csv(output_dir / "benchmark_metrics_v2.csv", index=False, encoding="utf-8-sig")
    return output_dir


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=Path("."))
    parser.add_argument("--output-dir", type=Path, default=Path("benchmark_results_v2"))
    args = parser.parse_args()
    result = run(args.data_dir, args.output_dir)
    print(f"ALL PAPER-ALIGNED ZERO-LEAKAGE GATES PASS: {result}")


if __name__ == "__main__":
    main()
