"""Rebuild the paper-aligned 6+18+5 CSV package from frozen inputs."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


ANNUALIZATION = 252
TIMEZONE = "Asia/Shanghai"
OOS_START = pd.Timestamp("2023-01-01", tz=TIMEZONE)
HORIZONS = [5, 20]
WINDOWS = [5, 22, 66]
SYMBOLS = ["I", "RB", "J", "JM"]

A_FEATURES = [
    "I_cumret_5", "I_cumret_22", "I_cumret_66",
    "I_daily_squared_return_vol_5", "I_daily_squared_return_vol_22",
    "I_daily_squared_return_vol_66",
]
B_ADD_FEATURES = [
    f"{symbol}_{kind}_{window}"
    for symbol in ["RB", "J", "JM"]
    for kind in ["cumret", "daily_squared_return_vol"]
    for window in WINDOWS
]
C_ADD_FEATURES = [
    "cpi_yoy", "ppi_yoy", "pmi_manufacturing",
    "industrial_value_added_yoy",
    "industrial_value_added_yoy_joint_jan_feb",
]
ABC_FEATURES = A_FEATURES + B_ADD_FEATURES + C_ADD_FEATURES
CV_PERIODS = [
    ("2020H2", "2020-07-01", "2020-12-31"),
    ("2021H1", "2021-01-01", "2021-06-30"),
    ("2021H2", "2021-07-01", "2021-12-31"),
    ("2022H1", "2022-01-01", "2022-06-30"),
    ("2022H2", "2022-07-01", "2022-12-31"),
]


def _localize(values: pd.Series) -> pd.Series:
    parsed = pd.to_datetime(values, errors="raise")
    return parsed.dt.tz_localize(TIMEZONE) if parsed.dt.tz is None else parsed.dt.tz_convert(TIMEZONE)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _market_features(source: pd.DataFrame) -> pd.DataFrame:
    result = pd.DataFrame()
    for symbol in SYMBOLS:
        returns = pd.to_numeric(source[f"{symbol}_r"], errors="coerce")
        for window in WINDOWS:
            result[f"{symbol}_cumret_{window}"] = returns.rolling(
                window, min_periods=window, center=False
            ).sum()
            result[f"{symbol}_daily_squared_return_vol_{window}"] = np.sqrt(
                ANNUALIZATION
                * returns.pow(2).rolling(window, min_periods=window, center=False).mean()
            )
    return result


def _macro_events(source: pd.DataFrame, name: str) -> pd.DataFrame:
    columns = [
        "forecast_time", name, f"{name}_release_time", f"{name}_period_end",
        f"{name}_period_start", f"{name}_joint_jan_feb",
        f"{name}_missing_latest_release",
    ]
    daily = source[columns].copy().rename(
        columns={
            name: "value",
            f"{name}_release_time": "release_time",
            f"{name}_period_end": "period_end",
            f"{name}_period_start": "period_start",
            f"{name}_joint_jan_feb": "joint_jan_feb",
            f"{name}_missing_latest_release": "missing_latest_release",
        }
    )
    for column in ["forecast_time", "release_time", "period_end", "period_start"]:
        daily[column] = _localize(daily[column])
    daily["value"] = pd.to_numeric(daily["value"], errors="coerce")
    daily["joint_jan_feb"] = pd.to_numeric(daily["joint_jan_feb"], errors="coerce")
    daily["missing_latest_release"] = daily["missing_latest_release"].fillna(False).astype(bool)
    states = [
        "value", "release_time", "period_end", "period_start",
        "joint_jan_feb", "missing_latest_release",
    ]
    previous = daily[states].shift(1)
    unchanged = daily[states].eq(previous) | (daily[states].isna() & previous.isna())
    changed = ~unchanged.all(axis=1)
    meaningful = daily["value"].notna() | daily["release_time"].notna() | daily["missing_latest_release"]
    events = daily.loc[changed & meaningful].copy()
    events["available_at"] = events["release_time"].where(
        events["value"].notna(), events["forecast_time"]
    )
    if events["available_at"].duplicated().any():
        raise AssertionError(f"Duplicate macro availability timestamps for {name}")
    return events.sort_values("available_at", kind="stable").reset_index(drop=True)


def _macro_features(source: pd.DataFrame, forecast_time: pd.Series) -> tuple[pd.DataFrame, pd.DataFrame]:
    result = pd.DataFrame(index=source.index)
    audit_rows = []
    for name in ["cpi_yoy", "ppi_yoy", "pmi_manufacturing", "industrial_value_added_yoy"]:
        events = _macro_events(source, name)
        joined = pd.merge_asof(
            pd.DataFrame({"forecast_time": forecast_time}).sort_values("forecast_time"),
            events[["available_at", "release_time", "value", "joint_jan_feb"]],
            left_on="forecast_time",
            right_on="available_at",
            direction="backward",
            allow_exact_matches=True,
        )
        result[name] = joined["value"].to_numpy()
        if name == "industrial_value_added_yoy":
            result["industrial_value_added_yoy_joint_jan_feb"] = joined["joint_jan_feb"].to_numpy()
        present = joined["value"].notna()
        future = present & (joined["release_time"] > joined["forecast_time"])
        missing_release = present & joined["release_time"].isna()
        audit_rows.append(
            {
                "variable": name,
                "n_value_present": int(present.sum()),
                "n_release_missing_when_value_present": int(missing_release.sum()),
                "n_future_release_violations": int(future.sum()),
                "status": "PASS" if not future.any() and not missing_release.any() else "FAIL",
            }
        )
    return result[C_ADD_FEATURES], pd.DataFrame(audit_rows)


def _future_volatility(returns: pd.Series, horizon: int) -> pd.Series:
    future = pd.concat([returns.shift(-step) for step in range(1, horizon + 1)], axis=1)
    return np.sqrt((ANNUALIZATION / horizon) * future.pow(2).sum(axis=1, min_count=horizon))


def _cv_folds(dataset: pd.DataFrame, horizon: int) -> pd.DataFrame:
    """Build paper-aligned expanding-window CV folds.

    Rules for every half-year fold:
    1. Training rows must be dated before the validation start, and their
       future-volatility labels must already be fully mature before that start.
    2. Validation rows must be dated inside the half-year AND their complete
       h-day label window must end no later than the same half-year end.
    3. All CV validation labels must remain strictly before the formal OOS
       period beginning 2023-01-01.

    The second rule is the key fix relative to the previous V2 implementation:
    it prevents end-of-half-year validation rows whose labels spill into the
    following half-year from being included in cv_folds while being excluded by
    the benchmark code.
    """
    rows = []
    label_end = f"label_end_{horizon}"

    for fold_id, start_text, end_text in CV_PERIODS:
        start = pd.Timestamp(start_text, tz=TIMEZONE)
        end = pd.Timestamp(end_text, tz=TIMEZONE)
        # forecast_time / label_end carry a 20:00 Asia/Shanghai timestamp.
        # Use the end of the calendar day so that a label ending on 12/31,
        # for example, is treated the same way as benchmark's date-only logic.
        end_of_day = end + pd.Timedelta(days=1) - pd.Timedelta(nanoseconds=1)

        train = (
            (dataset["forecast_time"] < start)
            & (dataset[label_end] < start)
        )

        validation = (
            dataset["forecast_time"].between(start, end_of_day)
            & (dataset[label_end] <= end_of_day)
            & (dataset[label_end] < OOS_START)
            & dataset[f"pre2023_mature_{horizon}"]
        )

        for role, mask in [("train", train), ("validation", validation)]:
            part = dataset.loc[mask, ["date", label_end]].copy()
            part.insert(1, "fold_id", fold_id)
            part.insert(2, "role", role)
            part["validation_start"] = start
            part["validation_end"] = end
            rows.append(part)

    result = pd.concat(rows, ignore_index=True)
    training = result["role"].eq("train")
    validation = result["role"].eq("validation")

    if not (result.loc[training, label_end] < result.loc[training, "validation_start"]).all():
        raise AssertionError(f"Label-maturity purge failed for h={horizon}")

    # Compare at calendar-date level because validation_end is stored at 00:00
    # while label_end timestamps are 20:00 Asia/Shanghai.
    validation_label_date = pd.to_datetime(result.loc[validation, label_end]).dt.date
    validation_end_date = pd.to_datetime(result.loc[validation, "validation_end"]).dt.date
    if not (validation_label_date <= validation_end_date).all():
        raise AssertionError(f"Validation label spills beyond fold end for h={horizon}")

    if not (result.loc[validation, label_end] < OOS_START).all():
        raise AssertionError(f"CV validation label enters formal OOS period for h={horizon}")

    return result


def rebuild(features_path: Path, targets_path: Path, output_dir: Path) -> Path:
    if output_dir.exists():
        raise FileExistsError(f"Refusing to overwrite existing output: {output_dir}")
    output_dir.mkdir(parents=True)
    features_source = pd.read_csv(features_path)
    targets_source = pd.read_csv(targets_path)
    if features_source["date"].duplicated().any() or targets_source["date"].duplicated().any():
        raise AssertionError("Frozen inputs contain duplicate dates")
    if not features_source["date"].equals(targets_source["date"]):
        raise AssertionError("Frozen feature and target dates are not aligned")

    forecast_time = _localize(features_source["forecast_time"])
    date = pd.to_datetime(features_source["date"], errors="raise")
    market = _market_features(features_source)
    macro, release_audit = _macro_features(features_source, forecast_time)
    feature_frame = pd.concat([market, macro], axis=1)[ABC_FEATURES]
    master = pd.DataFrame({"date": date, "forecast_time": forecast_time})
    master = pd.concat([master, feature_frame], axis=1)

    target_rows = []
    iron_returns = pd.to_numeric(features_source["I_r"], errors="coerce")
    abc_complete = feature_frame.notna().all(axis=1)
    for horizon in HORIZONS:
        volatility = _future_volatility(iron_returns, horizon)
        frozen = pd.to_numeric(targets_source[f"y_vol_{horizon}"], errors="coerce")
        finite = np.isfinite(volatility) & np.isfinite(frozen)
        same_nan = bool(np.array_equal(np.isnan(volatility), np.isnan(frozen)))
        finite_equal = bool(np.allclose(volatility[finite], frozen[finite], rtol=1e-11, atol=1e-13))
        maximum = float(np.max(np.abs(volatility[finite] - frozen[finite])))
        target_rows.append(
            {
                "horizon": horizon,
                "finite_values_equal": finite_equal,
                "same_nan_pattern": same_nan,
                "n_compared": int(finite.sum()),
                "max_abs_diff": maximum,
                "allclose_pass": finite_equal and same_nan,
                "status": "PASS" if finite_equal and same_nan else "FAIL",
            }
        )
        master[f"y_vol_{horizon}"] = volatility
        master[f"log_y_vol_{horizon}"] = np.where(volatility > 0, np.log(volatility), np.nan)
        master[f"label_end_{horizon}"] = forecast_time.shift(-horizon)
        eligible = abc_complete & volatility.notna() & (volatility > 0) & master[f"label_end_{horizon}"].notna()
        master[f"eligible_continuous_{horizon}"] = eligible
        master[f"pre2023_mature_{horizon}"] = (
            eligible & (forecast_time < OOS_START) & (master[f"label_end_{horizon}"] < OOS_START)
        )
        master[f"oos_{horizon}"] = eligible & (forecast_time >= OOS_START)

    target_audit = pd.DataFrame(target_rows)
    if not target_audit["allclose_pass"].all() or not release_audit["status"].eq("PASS").all():
        raise AssertionError("Target or release-time audit failed")

    master.to_csv(output_dir / "continuous_model_dataset_master_v2.csv", index=False, encoding="utf-8-sig")
    eligibility = master[[
        "date", "eligible_continuous_5", "pre2023_mature_5", "oos_5",
        "eligible_continuous_20", "pre2023_mature_20", "oos_20",
    ]]
    eligibility.to_csv(output_dir / "sample_eligibility_v2.csv", index=False, encoding="utf-8-sig")
    for horizon in HORIZONS:
        columns = [
            "date", "forecast_time", *ABC_FEATURES,
            f"y_vol_{horizon}", f"log_y_vol_{horizon}", f"label_end_{horizon}",
            f"pre2023_mature_{horizon}", f"oos_{horizon}", f"eligible_continuous_{horizon}",
        ]
        dataset = master.loc[master[f"eligible_continuous_{horizon}"], columns].reset_index(drop=True)
        dataset.to_csv(output_dir / f"model_dataset_h{horizon}_v2.csv", index=False, encoding="utf-8-sig")
        _cv_folds(dataset, horizon).to_csv(
            output_dir / f"cv_folds_h{horizon}_v2.csv", index=False, encoding="utf-8-sig"
        )
    target_audit.to_csv(output_dir / "target_verification_v2.csv", index=False, encoding="utf-8-sig")
    release_audit.to_csv(output_dir / "release_time_audit_v2.csv", index=False, encoding="utf-8-sig")
    (output_dir / "input_sha256_v2.json").write_text(
        json.dumps(
            {features_path.name: _sha256(features_path), targets_path.name: _sha256(targets_path)},
            ensure_ascii=False, indent=2,
        ) + "\n",
        encoding="utf-8",
    )
    return output_dir


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--features", type=Path, default=Path("inputs/features_asof.csv"))
    parser.add_argument("--targets", type=Path, default=Path("inputs/targets_and_splits.csv"))
    parser.add_argument("--output-dir", type=Path, default=Path("rebuilt_v2"))
    args = parser.parse_args()
    result = rebuild(args.features, args.targets, args.output_dir)
    print(f"PAPER-ALIGNED CSV BUILD PASS: {result}")


if __name__ == "__main__":
    main()
