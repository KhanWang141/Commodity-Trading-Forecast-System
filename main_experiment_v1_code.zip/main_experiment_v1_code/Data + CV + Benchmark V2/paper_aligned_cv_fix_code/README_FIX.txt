CV / benchmark consistency fix

1. Replace rebuild_paper_aligned_csv_v2.py with this version.
   Validation rows now require both forecast_time inside the half-year and label_end_h no later than the same half-year end.

2. Replace run_zero_leakage_benchmarks_v2.py with this version.
   It now asserts that cv_folds_h*_v2.csv and the benchmark's internally constructed train/validation date sets are exactly identical before calculating benchmarks.

3. paper_aligned_cv.py is unchanged because build_calendar_splits() already had the correct stricter rule.

4. Replace test_paper_aligned_cv.py with this version.
   It adds a unit test ensuring validation labels cannot spill into the next half-year.

Validated locally:
- pytest: 3 passed
- rebuilt data: PASS
- zero-leakage benchmark: PASS
- h=5 validation counts: 121, 113, 120, 112, 120
- h=20 validation counts: 106, 98, 105, 97, 105
