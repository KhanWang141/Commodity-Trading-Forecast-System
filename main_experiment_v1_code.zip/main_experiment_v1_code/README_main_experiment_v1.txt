Iron Ore Main Experiment Protocol V1.0 — Run Guide
===================================================

Required frozen V2 inputs in --data-dir:
  model_dataset_h5_v2.csv
  model_dataset_h20_v2.csv
  cv_folds_h5_v2.csv
  cv_folds_h20_v2.csv

IMPORTANT CV gate
-----------------
The program refuses to run if cv_folds_h*_v2.csv do not exactly match the strict
paper-aligned splits:
  train: date < validation_start AND label_end_h < validation_start
  valid: validation_start <= date <= validation_end AND label_end_h <= validation_end
         AND label_end_h < 2023-01-01

Expected validation counts after the CV fix:
  h=5 : 121, 113, 120, 112, 120
  h=20: 106,  98, 105,  97, 105

Recommended execution
---------------------
1) Test environment:
   python run_main_experiment_v1.py --stage self-test

2) Ridge CV:
   python run_main_experiment_v1.py \
       --data-dir <V2_DATA_DIR> \
       --output-dir main_experiment_v1 \
       --stage ridge-cv

3) XGBoost CV (full frozen 864-combination grid; resume supported):
   python run_main_experiment_v1.py \
       --data-dir <V2_DATA_DIR> \
       --output-dir main_experiment_v1 \
       --stage xgb-cv \
       --resume

4) Formal OOS after all 12 Ridge/XGB best-parameter files exist:
   python run_main_experiment_v1.py \
       --data-dir <V2_DATA_DIR> \
       --output-dir main_experiment_v1 \
       --stage oos \
       --resume

Do NOT inspect formal OOS and then alter the frozen CV/search protocol.
For strongest reproducibility keep --xgb-n-jobs 1.

Main outputs
------------
main_experiment_v1/
  protocol_metadata.json
  cv_artifact_consistency_audit.csv
  cv/
    cv_all_candidates.csv
    cv_best_params.csv
    cv_best_predictions.csv
    candidates_*.csv
    best_*.json
  oos/
    oos_predictions.csv
    oos_monthly_training_audit.csv
    oos_metrics.csv
    information_increment.csv
    dm_tests_core.csv
    dm_tests_supplementary.csv

Dependencies
------------
Python 3.10+
numpy
pandas
scipy
scikit-learn
xgboost
